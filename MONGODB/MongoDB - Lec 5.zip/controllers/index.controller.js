const db = require("../connection")
const {ObjectId} = require("mongodb")

function RenderHome(req, res) {
    res.render("index")
}

async function AddNewStaff(req, res) {
    const {name, email, mobile, gender} = req.body

    const document = {
        name: name,
        email: email,
        mobile: mobile,
        gender: gender
    }

    const collection = "staff"
    try {
        await db.collection(collection).insertOne(document)
        res.json({error: '', message: 'New Staff Member Created.'})
    } catch (e) {
        res.json({error: e.message, message: ''})
    }
}

async function ReadStaffMembers(req, res) {
    try {
        let collection = "staff"
        let documents = await db.collection(collection).find().toArray()
        res.json({error: '', documents: documents})
    } catch (e) {
        res.json({error: e.message, documents: []})
    }
}

async function DeleteStaffMember(req, res) {
    try {
        let {_id} = req.params
        let collection = "staff"
        let filter = {_id: new ObjectId(_id)}
        let result = await db.collection(collection).deleteOne(filter)
        res.json({error: '', message: 'Document Deleted.'})
    } catch (e) {
        res.json({error: e.message, message: ''})
    }
}

async function UpdateStaff(req, res) {
    try {
        let {_id} = req.params
        let {name, email, mobile, gender} = req.body
        let collection = "staff"

        let filter = {_id: new ObjectId(_id)}
        let updateData = {
            name: name,
            email: email,
            mobile: mobile,
            gender: gender
        }
        await db.collection(collection).updateOne(filter, {$set: updateData})
        res.json({error: '', message: 'Staff Updated.'})
    } catch (e) {
        res.json({error: e.message, message: ''})
    }
}

module.exports = {
    UpdateStaff,
    DeleteStaffMember,
    ReadStaffMembers,
    AddNewStaff,
    RenderHome
}