const express = require("express")
const app = express()
const indexController = require("./controllers/index.controller")

app.use(express.static('public'))
app.use(express.json())

/* setup view engine... */
app.set("view engine", "ejs")

app.put('/staff/:_id', indexController.UpdateStaff)
app.delete("/staff/:_id", indexController.DeleteStaffMember)
app.post("/staff", indexController.AddNewStaff)
app.get("/staff", indexController.ReadStaffMembers)

app.get("/", indexController.RenderHome)

const PORT = 3000
app.listen(PORT, (error) => {
    if (error) {
        console.log(error)
    } else {
        console.log("Node Server is Running.")
    }
})