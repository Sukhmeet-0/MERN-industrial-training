const Footer = () => {
  return(
      <div className="container-fluid">
          <div className="row bg-dark text-white text-center py-3">
              <div className="col-6 text-center">&copy;2024</div>
              <div className="col-6 text-center">VMM Education</div>
          </div>
      </div>
  )
}

export default Footer