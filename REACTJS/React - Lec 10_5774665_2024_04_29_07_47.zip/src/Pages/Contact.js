// import Navbar from "../Components/Navbar";

import {useState} from "react"; // 1. hook

let Contact = () => {
    // let name = 'John'

    // let numbers = [10,20,30,40];
    // let [a, b, c, d] = [10,20,30,40];
    // console.log(a) // 10
    // console.log(b) // 20
    // console.log(c) // 30
    // console.log(d) // 40

    // let name = useState("John") // initialize
    // let [name, setName] = useState("Pratham") // 2. initialize
    // console.log(name) // 1. initial value, 2. function (update state value) -> Array
    // console.log(name)
    // console.log(setName)

    // function updateName() {
    //     setName("Suraj") // function (update state value)
    // }

    // let [names, setNames] = useState(['Kartik', 'Vasu', 'Pratham'])
    // console.log(names)

    // function newName() {
    // setNames(['Aryan'])
    // ... (Spread Operator)
    // setNames((prevState) => [...prevState, 'Aryan', 'Kanish'])
    // setNames((prevState) => ['Kartik', 'Vasu', 'Pratham', 'Aryan'])
    // }

    let [users, setUsers] = useState({
        name: "Pratham",
        age: 23,
        gender: "Male",
    });

    // function mobileNumber() {
    // setUsers({mobile: '1234567890'})
    // setUsers((prevState) => ({...prevState, 'mobile': '1234567890'}))
    // }

    // ['name', 'age', 'gender']
    // Object.keys(users).map((value) => console.log(users[value]))

    let [email, setEmail] = useState("");
    let [password, setPassword] = useState("");

    function handleInput(event) {
        // console.log(event.target.value)
        setEmail(event.target.value);
    }

    function handleInput2(event) {
        // console.log(event.target.value)
        setPassword(event.target.value);
    }

    function handleForm(event) {
        event.preventDefault();
        console.log("email", email);
        console.log("password", password);
    }

    console.log("Component Rendered...")

    return (
        <>
            <div className={"container"}>
                <h1>Contact Us Page</h1>

                <form onSubmit={handleForm}>
                    <input type="text" onKeyUp={handleInput} placeholder="enter email"/>{" "}
                    <br/>
                    <input
                        type="text"
                        onKeyUp={handleInput2}
                        placeholder="enter password"
                    />{" "}
                    <br/>
                    <button type="submit">submit</button>
                </form>

                {/*<button onClick={mobileNumber}>show mobile number</button>*/}

                {/*{Object.keys(users).map((value) =>*/}
                {/*    <p>{value} {users[value]}</p>*/}
                {/*)}*/}

                {/*<button onClick={newName}>add new name</button>*/}

                {/*{names.map((value, index) =>*/}
                {/*    <p key={index}>{index} - {value}</p>*/}
                {/*)}*/}

                {/*<h4>{name}</h4>*/}

                {/*<button onClick={updateName}>update name</button>*/}
                {/*<button onClick={() => setName('Suraj')}>update name</button>*/}
            </div>
        </>
    );
};
export default Contact;
