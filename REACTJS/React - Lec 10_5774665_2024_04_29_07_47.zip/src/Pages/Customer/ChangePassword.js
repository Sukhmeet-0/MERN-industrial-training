const ChangePassword = () => {
    return (
        <>
            <h2>Change Password</h2>
        </>
    )
}

export default ChangePassword