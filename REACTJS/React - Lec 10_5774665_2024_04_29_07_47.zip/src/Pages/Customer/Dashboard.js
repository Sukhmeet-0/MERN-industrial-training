const Dashboard = () => {
    return (
        <>
            <h2>Customer Dashboard</h2>
        </>
    )
}
export default Dashboard