// import Navbar from "../Components/Navbar";

// import {go, go2} from "../Config"
// import Go3Fun, { go, go2 } from "../Config";

// import "../About.css"
import Style from "../About.module.css"
import {useEffect, useState} from "react";

let About = () => {
    let data = [
        {roll: 1, name: 'Amrinder', sub: 'Eng', marks: 90},
        {roll: 2, name: 'Shalinder', sub: 'Eng', marks: 91},
        {roll: 1, name: 'Amrinder', sub: 'Maths', marks: 95},
        {roll: 2, name: 'Shalinder', sub: 'Computer', marks: 92},
        {roll: 1, name: 'Amrinder', sub: 'Computer', marks: 94},
    ]

    /* -------------------------------------------------- */
    let uniqueStudents = {};
    data.forEach(student => {
        if (!uniqueStudents.hasOwnProperty(student.roll)) {
            uniqueStudents[student.roll] = {roll: student.roll, name: student.name, details: []};
        }
        uniqueStudents[student.roll].details.push({subject: student.sub, marks: student.marks});
    });
    uniqueStudents = Object.values(uniqueStudents);
    // console.log(uniqueStudents);
    /* -------------------------------------------------- */
    // let uniqueStudents = Object.values(data.reduce((acc, cur) => {
    //     if (!acc[cur.roll]) {
    //         acc[cur.roll] = {roll: cur.roll, name: cur.name, details: []};
    //     }
    //     acc[cur.roll].details.push({subject: cur.sub, marks: cur.marks});
    //     return acc;
    // }, {}));
    // console.log(uniqueStudents);
    /* -------------------------------------------------- */

    return (
        <>
            <div className={"container"}>
                <h1 className={Style.heading}>Students</h1>
                {uniqueStudents.map(x =>
                    <div className="alert alert-dark" key={x.roll}>
                        <div className="row">
                            <div className="col-6">
                                <h5>Roll Number - {x.roll}</h5>
                                <h5>Name - {x.name}</h5>
                            </div>

                            <div className="col-6">
                                <h3>Marks</h3>
                                {x.details.map(y =>
                                    <span className="badge bg-success me-1">{y.subject} {y.marks}</span>
                                )}
                            </div>
                        </div>
                    </div>
                )}
            </div>
        </>
    );
};
export default About;
