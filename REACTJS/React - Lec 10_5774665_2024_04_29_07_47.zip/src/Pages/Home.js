// import Navbar from "../Components/Navbar";
import Cards from "../Components/Cards";
// import Footer from "../Components/Footer";

import { useState } from 'react';
import Button from 'react-bootstrap/Button';
import Modal from 'react-bootstrap/Modal';

// import "../Home.css"
import Style from "../Style.module.css"

let Home = () => {

    const [show, setShow] = useState(false);

    const handleClose = () => setShow(false);
    const handleShow = () => setShow(true);

    return (
        <>
            <h1 className={Style.heading}>Heading</h1>

            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Magnam, nihil!</p>

            <Button variant="primary" onClick={handleShow}>
                Launch demo modal
            </Button>

            <Modal size="lg" centered show={show} onHide={handleClose}>
                <Modal.Header closeButton>
                    <Modal.Title>Modal heading</Modal.Title>
                </Modal.Header>
                <Modal.Body>Woohoo, you are reading this text in a modal!</Modal.Body>
            </Modal>
        </>
    )
}
export default Home;