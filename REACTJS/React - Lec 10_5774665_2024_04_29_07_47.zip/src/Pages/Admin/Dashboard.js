const Dashboard = () => {
    return (
        <>
            <h2>Admin Home Page</h2>
        </>
    )
}

export default Dashboard