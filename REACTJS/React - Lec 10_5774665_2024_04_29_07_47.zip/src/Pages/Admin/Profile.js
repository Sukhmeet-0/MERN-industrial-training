const Profile = () => {
    return (
        <>
            <h2>Admin Profile Page</h2>
        </>
    )
}

export default Profile