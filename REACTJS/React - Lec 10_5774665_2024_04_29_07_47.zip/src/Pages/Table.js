import { useEffect, useState } from "react";

function Table() {
  // start
  const [users, setUsers] = useState([]);

  useEffect(() => {
    // API Request (start)
    // const url = "https://vmmeducation.com/vmmapi/allstudents";
    const url = "https://vmmeducation.com/vmmapi/getstudents";
    fetch(url)
      .then((response) => response.json())
      .then((data) => {
        // console.log(data.ans);
        setUsers(data.ans); // update state variable
      });
    // API Request (end)
  }, []);

  const [roll, setRoll] = useState("");

  function SearchStudent() {
    const url = "https://vmmeducation.com/vmmapi/student/" + roll;

    fetch(url)
      .then((response) => response.json())
      .then((data) => {
        console.log(data); // {roll: '1'}
        setUsers([data]); // {roll: '1'} -> [{roll: '1'}] (1 Element)
      });
  }

  return (
    <div className="container pt-5">
      <input
        type="text"
        onKeyUp={(event) => setRoll(event.target.value)}
        placeholder="search student..."
        className="form-control mb-3"
      />

      <button className="btn btn-primary mb-3" onClick={SearchStudent}>
        Search
      </button>

      <table className="table table-dark table-hover">
        <thead>
          <tr>
            <th>Roll Number</th>
            <th>Name</th>
            <th>Marks</th>
            <th>Photo</th>
          </tr>
        </thead>

        <tbody>
          {users.map((x) => (
            <tr key={x.rollno}>
              <td>{x.rollno}</td>
              <td>{x.name}</td>
              <td>{x.marks}</td>
              <td>
                <img src={x.photo} alt="" style={{ width: "100px" }} />
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default Table;
