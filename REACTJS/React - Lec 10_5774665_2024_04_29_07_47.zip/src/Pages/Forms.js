import {useForm} from "react-hook-form"
import { ErrorMessage } from '@hookform/error-message';

const Forms = () => {

    const {
        register,
        handleSubmit,
        formState: {errors}
    } = useForm()

    function handleForm(data) {
        console.log(data)
    }

    // console.log("comp render...")

    return (
        <div className="container">
            <h1>React Hook Form Example</h1>
            <hr/>
            <div className="alert alert-primary">
                <form onSubmit={handleSubmit(handleForm)}>
                    <div className="mb-3">
                        <label htmlFor="">Name</label>
                        <input {...register("userName", {required: 'Please enter your name.'})} type="text" className="form-control"/>
                        <ErrorMessage
                            errors={errors}
                            name="userName"
                            render={({ message }) => <p className="text-danger fw-bold">{message}</p>}
                        />
                    </div>

                    <div className="mb-3">
                        <label htmlFor="">Email</label>
                        <input {...register("email", {required: 'This field is required.'})} type="email" className="form-control"/>
                        <ErrorMessage
                            errors={errors}
                            name="email"
                            render={({ message }) => <p className="text-danger fw-bold">{message}</p>}
                        />
                    </div>

                    <div className="mb-3">
                        <label htmlFor="">Password</label>
                        <input {...register('password', {required: 'This field is required.'})} type="password" className="form-control"/>
                        <ErrorMessage
                            errors={errors}
                            name="password"
                            render={({ message }) => <p className="text-danger fw-bold">{message}</p>}
                        />
                    </div>

                    <div className="mb-3">
                        <label htmlFor="">Mobile</label>
                        <input {...register('mobileNumber', {required: 'This field is required.'})} type="tel" className="form-control"/>
                        <ErrorMessage
                            errors={errors}
                            name="mobileNumber"
                            render={({ message }) => <p className="text-danger fw-bold">{message}</p>}
                        />
                    </div>

                    <button className="btn btn-primary">Submit</button>
                </form>
            </div>
        </div>
    )
}

export default Forms