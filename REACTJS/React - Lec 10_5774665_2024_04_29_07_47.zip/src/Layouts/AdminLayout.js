import NavbarAdmin from "../Components/NavbarAdmin";
import Footer from "../Components/Footer";
import {Outlet} from "react-router-dom";

const PublicLayout = () => {
    return (
        <>
            <NavbarAdmin/>
            <Outlet/>
            <Footer/>
        </>
    )
}

export default PublicLayout