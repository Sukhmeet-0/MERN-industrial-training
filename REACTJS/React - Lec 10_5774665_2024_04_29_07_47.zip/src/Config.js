// export function go() {
//     console.log("hello world.")
// }

// export function go2() {
//     console.log("go2 func called")
// }

function go() {
    console.log("hello world.")
}

function go2() {
    console.log("go2 func called")
}

export {go, go2} // Named Export

function go3() {
    console.log("go3 function Called")
}

export default go3 // Default Export