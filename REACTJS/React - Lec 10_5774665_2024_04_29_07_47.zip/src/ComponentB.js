let ComponentB = () => {
    function printValue(val) {
        alert(val)
    }

    let fetchVal = (e) => {
        console.log(e.target.value)
    }
    // let arr = [1, "Two", 3, 4, 5];

    let arr = []
    let myCondition = true;
    /*if(myCondition) {
        return <h1>Condition is true</h1>

    }*/

    return (
        <>
            <button type={"button"} className={"btn btn-primary"} onClick={() => printValue('React')}> Click Me</button>
            <input type={"text"} onChange={fetchVal} className={"form-control"}/>
            {arr.length ?
                <ul>
                    {arr.map((a, b) => {
                        return <li key={b}>{b + " " + a}</li>
                    })}
                </ul> : <p>No data found</p>}
            {myCondition && <>Condition is true
                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Amet aperiam exercitationem hic itaque
                    maiores maxime odio recusandae reiciendis voluptate voluptatum?</p>
            </>
            }
        </>
    )
}
export default ComponentB