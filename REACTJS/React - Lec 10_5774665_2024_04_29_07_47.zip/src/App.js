import {BrowserRouter, Routes, Route} from "react-router-dom";
import Home from "./Pages/Home";
import Contact from "./Pages/Contact";
import About from "./Pages/About";
import PageNotFound from "./Pages/PageNotFound";
import PublicLayout from "./Layouts/PublicLayout";
import Forms from "./Pages/Forms";
import Table from "./Pages/Table";

import Dashboard from "./Pages/Admin/Dashboard";
import Profile from "./Pages/Admin/Profile";
import AdminLayout from "./Layouts/AdminLayout";

import CustomerDashboard from "./Pages/Customer/Dashboard"
import ChangePassword from "./Pages/Customer/ChangePassword";

function App() {
    return (
        <BrowserRouter>
            <Routes>
                {/*<Route path="/" element={<Home/>} />*/}
                {/*<Route path="/about" element={<About/>} />*/}
                {/*<Route path="/contact" element={<Contact/>} />*/}

                {/* PUBLIC ROUTES */}
                <Route path="/" element={<PublicLayout/>}>
                    <Route index element={<Home/>} />
                    <Route path="about" element={<About/>} />
                    <Route path="contact" element={<Contact/>} />
                    <Route path="register" element={<Forms/>} />
                    <Route path="table" element={<Table/>} />
                </Route>

                <Route path="/admin" element={<AdminLayout/>}>
                    <Route path="dashboard" element={<Dashboard/>} />
                    <Route path="profile" element={<Profile/>} />
                </Route>

                <Route path="/customer">
                    <Route path="dashboard" element={<CustomerDashboard/>} />
                    <Route path="change-password" element={<ChangePassword/>} />
                </Route>

                <Route path="*" element={<PageNotFound/>} />
            </Routes>
        </BrowserRouter>
    )
}

export default App;
